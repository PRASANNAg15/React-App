import { useState } from "react";
import "./search.css";
function SearchBar(props){
     const[name,setName]=useState("");
     const[age,setAge]=useState(0);
     const[course,setCourse]=useState("");
     const[show,setShow]=useState(false);
 
     let arr=props.arr;
function find(){
    if(name==="")
    {
        alert("Empty !!!! ");
        setName("");
    }
    else{
    arr.find(s=>{
        if(s.name===name)
        {
            alert("Details found");
            setAge(s.age);
            setCourse(s.course);
            setShow(true);
        }
        else{
            alert("Details Not found");
        }
    })
}
}
return(
    <>
    <form>
        <label>Enter the Name:</label>
        <input type="text" onChange={(e)=>setName(e.target.value)}/>
        <br /><br />
        <button type="button" onClick={find}>Find</button>
    </form>
    {show &&(
    <form>
        <h1>Name:{name}</h1>
        <p>Age:{age}</p>
        <p>Course:{course}</p>
    </form>
    )}
    </>
)
}
export default SearchBar;