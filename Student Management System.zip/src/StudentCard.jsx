import { useState } from "react"
import "/src/StudentCard.css"
function StudentCard(props)
{
  const[show,setShow]=useState(false);
  let s=props.arr||[];
  
    return(
        <>
         <h1>Student Details</h1>
        {s.length>0?(
        <div id="outer">
       {s.map((a)=>(
        <div id="cards">
            <img src="src/assets/profile.jpg" alt="profile" />
              <p>Name:{a.name}</p>
              <p>Age:{a.age}</p>
              <p>Course:{a.course}</p>
        </div>
       ))}
       </div>):(
         <h1 align="center">No students added</h1>
       )}
        </>
    );
}
export default StudentCard;