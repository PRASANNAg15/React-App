import { useState } from "react";
import StudentCard from "./StudentCard.jsx";
import StudentsList from "./StudentsList.jsx";
import SearchBar from "./SearchBar.jsx";
import "./ShowForm.css";
function StudentForm() {
  const [name, setName] = useState();
  const [age, setAge] = useState();
  const [course, setCourse] = useState();
  const [students, setStudents] = useState([]);
  const [showList, setShowList] = useState(false);
  const [showCard, setShowCard] = useState(false);
  const [showform, setshowForm] = useState(false);
  const [search, setSearch] = useState(false);
  const [del, setDel] = useState(false);
  const [delname, setDelName] = useState("");


  function Register() {
    setshowForm(true);
    setDel(false);
    setSearch(false);
    setShowList(false);
    setShowCard(false);
    setAge("");
    setCourse("");
    setName("");
  }
  function handleDelete() {
    students.forEach(element => {
      if (element.name === delname && confirm("Do you want to Delete")) {
        setStudents(students.filter((s) => s.name !== delname));
        alert("Deleted Successfully");
        setDelName("");
      }
    });
  }
  function list() {
    setShowList(true);
    setShowCard(false);
    setSearch(false);
    setDel(false);
    setshowForm(false);
  }
  function card() {
    setShowCard(true);
    setShowList(false);
    setDel(false);
    setSearch(false);
    setshowForm(false);

  }
  function handleSubmit() {
    if(name===""||age===""||course==="")
    {
      alert("Empty!!!!");
    }
    else{
    setStudents(students => [...students, { name: name, age: age, course: course }]);
    alert("Registered Successfully")
    console.log(students);
    }
  }

  function Search() {
    setSearch(true);
    setShowList(false);
    setShowCard(false);
    setshowForm(false);
  }
  function deleteStudent() {
    setDel(true);
    setSearch(false);
    setShowList(false);
    setShowCard(false);
    setshowForm(false);
  }
  return (
    <>
      <div id="welcome">
        <h1 align="center">Welcome to Student Management System </h1>
      </div>
      <div id="total">
        <h1>Total Students:{students.length}</h1>
      </div>
      {showform && (
        <form id="addform">
          <h1 align="center">Add Student</h1>
          <label>Enter the Name:</label>
          <input type="text" required onChange={(e) => setName(e.target.value)} />
          <br /><br />
          <label>Enter the Age:</label>
          <input type="text" required onChange={(e) => setAge(e.target.value)} />
          <br /><br />
          <label>Enter the Course:</label>
          <input type="text" required onChange={(e) => setCourse(e.target.value)} />
          <br /><br />
          <button type="button" onClick={handleSubmit}>Submit</button>
        </form>
      )}

      <div id="buttons">
        <button id="register" type="button" onClick={Register}>Register</button>
        <button id="list" type="button" onClick={list}>Show Students List</button>
        <button id="card" type="button" onClick={card}>Student card information</button>
        <button type="button" onClick={Search}>Search</button>
        <button type=" button" onClick={deleteStudent}>Delete</button>
      </div>

      {del && !search && !showCard && !showList && (
        <form id="delform">
          <label>Enter the Name of the student:</label>
          <input type="text" onChange={(e) => setDelName(e.target.value)} />
          <br /><br />
          <button type="button" id="delbtn" onClick={handleDelete}>Delete</button>
        </form>
      )}


      {showCard && !showList && (
        <StudentCard arr={students} />)}
      {showList && !showCard && (
        <StudentsList arr={students} />
      )}
      {search && !showCard && !showList && (
        <SearchBar arr={students} />
      )}
    </>
  )
}
export default StudentForm;