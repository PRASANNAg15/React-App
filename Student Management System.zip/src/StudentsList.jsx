import { useState } from "react";
import "./list.css";
function StudentsList(props){
   let students=props.arr||[];

      return(
        <>{students.length>0 ?(
        <table>
            <thead>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Course</th>
            </tr>
            </thead>
            <tbody>
            {students.map(a=>(
            <tr>
                <td>{a.name}</td>
                <td>{a.age}</td>
                <td>{a.course}</td>
            </tr>
            ))}
            </tbody>
        </table>
):(
    <h1 align="center">No details found</h1>
)}
        </>
      )
}
export default StudentsList;
