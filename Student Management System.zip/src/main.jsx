import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import StudentForm from './StudentForm'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <StudentForm />
  </StrictMode>
)
